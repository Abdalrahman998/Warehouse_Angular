export class signInModel{
    username:string
    password:string
}