export class role{
    id:string
    name:string
}