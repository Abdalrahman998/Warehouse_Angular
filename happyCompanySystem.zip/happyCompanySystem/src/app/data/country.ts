export class country{
    id:number;
    name:string;
}