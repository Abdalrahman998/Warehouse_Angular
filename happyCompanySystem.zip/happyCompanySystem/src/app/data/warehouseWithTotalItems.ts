import { warehouse } from "./warehouse";

export class warehouseWithTotalItems{
    warehouse:warehouse
    totalItems:number
}