
export class user{
    id:string
    firstName:string
    middleName:string
    lastName:string
    email:string
}