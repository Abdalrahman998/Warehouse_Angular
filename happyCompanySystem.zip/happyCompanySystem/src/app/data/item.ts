import { warehouse } from "./warehouse";

export class item{
    id:number;
    name:string;
    skuCode:string
    qty:number
    costPrice:number
    msrpPrice:number
    warehouse_Id:number
    warehouse:warehouse
}