import { country } from "./country";

export class warehouse{
    id:number;
    name:string;
    address:string;
    city:string;
    country_Id:number;
    country:country
}