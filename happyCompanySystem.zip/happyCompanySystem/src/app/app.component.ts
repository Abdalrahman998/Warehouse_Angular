import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'happyCompanySystem';
  decodedToken?:any=""
  role:string
  isAdmin:boolean
  constructor(private router:Router){}
  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
      this.isLogin=true

      var Token = (localStorage.getItem("Token"))
      this.decodedToken = jwt_decode(Token!)
      this.role = this.decodedToken.Role
    }
    else{
      this.isLogin=false
    }
    if(this.role=="Admin"){
      this.isAdmin=true
    }
    else{
      this.isAdmin=false
    }
  }
  gotoItems(){
    this.router.navigate(['/item'],{queryParams:{warehouseId:0}})
  }
  addItem(){
    this.router.navigate(['/add/item'],{queryParams:{itemId:0}})
  }
  logout(){
    localStorage.clear();
  }
  isLogin:boolean
  
  
}
