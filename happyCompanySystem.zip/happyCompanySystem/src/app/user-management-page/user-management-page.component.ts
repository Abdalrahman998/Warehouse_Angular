import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { user } from '../data/user';
import { accountService } from '../services/accountService';
import jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-user-management-page',
  templateUrl: './user-management-page.component.html',
  styleUrls: ['./user-management-page.component.css']
})
export class UserManagementPageComponent implements OnInit {

  liUser:user[]
  adminId:string="a9701500-b0e0-45f6-bfcd-e0becb151568"
  decodedToken?:any=""
  role:string
  constructor(private accountService:accountService,private router:Router) { }

  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
      var Token = (localStorage.getItem("Token"))
      this.decodedToken = jwt_decode(Token!)
      this.role = this.decodedToken.Role
      if(this.role=="Admin"){
    this.accountService.getUsers().subscribe({
      next:data=>{
        this.liUser=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
  }
  else{
    this.router.navigate([''])
  }
  }
  else{
    this.router.navigate([''])
  }
  }
  onDelete(id:string){
    if(confirm("Are you sure to delete this user?")){
    this.accountService.delete(id).subscribe({
      next:data=>{
        alert("User deleted")
      },
      error:e=>{
        alert("error: "+e)
      }
    });
  }
  }
  onEdit(username:string){
    this.router.navigate(['/add/user'],{queryParams:{username:username}})
  }

}
