import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { item } from '../data/item';
import { warehouse } from '../data/warehouse';
import { itemService } from '../services/itemService';
import { warehouseService } from '../services/warehouseService';

@Component({
  selector: 'app-new-item',
  templateUrl: './new-item.component.html',
  styleUrls: ['./new-item.component.css']
})
export class NewItemComponent implements OnInit {

  @ViewChild('f1') form1:NgForm
  itemId:number=this.act.snapshot.queryParams["itemId"]
  liWarehouse:warehouse[]
  modaHeader:string
  isNull:boolean
  itemObj:item
  errorMsg:string
  constructor(private itemService:itemService,private warehouseService:warehouseService,private act:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
    this.warehouseService.loadAll().subscribe({
      next:data=>{
        this.liWarehouse=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
    if(this.itemId != 0){
      this.isNull=false
      this.modaHeader="Edit"
      this.itemService.load(this.itemId).subscribe({
        next:data=>{
          this.itemObj=data
          this.form1.form.patchValue({
            "txtName":this.itemObj.name,
            "hidId":this.itemObj.id,
            "txtSKU":this.itemObj.skuCode,
            "txtQty":this.itemObj.qty,
            "txtCost":this.itemObj.costPrice,
            "txtMSRP":this.itemObj.msrpPrice,
            "ddlWarehouse":this.itemObj.warehouse_Id
          })
        },
        error:e=>alert("Error: "+e)
      })
    }
    else{
      this.isNull=true
      this.modaHeader="Add"
    }
  }
  else{
    this.router.navigate([''])
  }
  }
  onSave(){
    debugger
    var i = new item()
    i.name = this.form1.value["txtName"]
    i.skuCode = this.form1.value["txtSKU"]
    i.qty = parseInt(this.form1.value["txtQty"])
    i.costPrice = parseFloat(this.form1.value["txtCost"])
    i.msrpPrice = parseFloat(this.form1.value["txtMSRP"])
    i.warehouse_Id = parseInt(this.form1.value["ddlWarehouse"])
    this.itemService.insert(i).subscribe({
      next:()=>{
        alert("Item saved")
      },
      error:e=>{console.log("Error: "+e),
      this.errorMsg = "Please fill all required"
    }
    })
  }
  onUpdate(){
    var i = new item()
    i.id = this.form1.value["hidId"]
    i.name = this.form1.value["txtName"]
    i.skuCode = this.form1.value["txtSKU"]
    i.qty = parseInt(this.form1.value["txtQty"])
    i.costPrice = parseFloat(this.form1.value["txtCost"])
    i.msrpPrice = parseFloat(this.form1.value["txtMSRP"])
    i.warehouse_Id = parseInt(this.form1.value["ddlWarehouse"])
    this.itemService.update(i).subscribe({
      next:()=>{
        alert("Item updated")
      },
      error:e=>{console.log("Error: "+e),
      this.errorMsg = "Please fill all required"
    }
    })
  }

}
