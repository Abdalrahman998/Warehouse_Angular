import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { country } from '../data/country';
import { countryService } from '../services/countryService';
//import * as $ from "jquery";
declare let $: any
@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  liCountry:country[]
  countryObj:country
  @ViewChild('f1') form1:NgForm
  name:string
  isNull:boolean
  succsMsg:string
  modalHeader:string
  errorMsg:string
  constructor(private countryService:countryService,private router:Router) { }

  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
    this.countryService.loadAll().subscribe({
      next:data=>{
        this.liCountry=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
  }
  else{
    this.router.navigate([''])
  }
  }
  hideSuccesfullyBox(){
    $("#succesfullyRow").hide()
  }
  onSave(){
    var c = new country()
    c.name = this.form1.value["txtName"]
    this.countryService.insert(c).subscribe({
      next:()=>{
        debugger
        this.countryService.loadAll().subscribe({
          next:data=>{
            this.liCountry=data
            this.succsMsg = "created"
            $("#succesfullyRow").show()
            $("#popupmodel").modal('toggle')
          },
          error:e=>{
            alert("error: "+e)
          }
        });
      },
      error:e=>{console.log("Error: "+e),
      this.errorMsg="Please fill all required"
    }
    })
  }
  onDelete(id:number){
    if(confirm("Are you sure to delete this item?")){
      this.countryService.delete(id).subscribe({
        next:()=>{
          this.countryService.loadAll().subscribe({
            next:data=>{
              this.liCountry=data
              this.succsMsg = "deleted"
            $("#succesfullyRow").show()
            },
            error:e=>{
              alert("error: "+e)
            }
          });
        },
        error:e=>alert("Error: "+e)
      })
  }
  }
  onSearch(text:any){
    this.name=text.target.value
    if(this.name != ""){
      this.countryService.search(this.name).subscribe({
        next:data=>{
          this.liCountry=data
        },
        error:e=>alert("Error: "+e)
      })
  }
  else{
    this.countryService.loadAll().subscribe({
      next:data=>{
        this.liCountry=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
}
  }
  addCountry(){
    this.errorMsg=""
    this.isNull=true
    this.modalHeader="Add"
    this.form1.form.patchValue({
      "txtName":null,
      "hidId":0
    })
  }
  onEdit(id:number){
    this.errorMsg=""
    this.isNull=false
    this.modalHeader="Edit"
    this.countryService.load(id).subscribe({
      next:data=>{
        this.countryObj=data
        this.form1.form.patchValue({
          "txtName":this.countryObj.name,
          "hidId":this.countryObj.id
        })
      },
      error:e=>alert("Error: "+e)
    })
  }
  onUpdate(){
    var c = new country()
    c.id = this.form1.value["hidId"]
    c.name = this.form1.value["txtName"]
    this.countryService.update(c).subscribe({
      next:()=>{
        this.countryService.loadAll().subscribe({
          next:data=>{
            this.liCountry=data
            this.succsMsg = "updated"
            $("#succesfullyRow").show()
            $("#popupmodel").modal('toggle')
          },
          error:e=>{
            alert("error: "+e)
          }
        });
      },
      error:e=>{console.log("Error: "+e),
      this.errorMsg="Please fill all required"
    }
    })
  }

}
