import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import * as $ from "jquery";
import { country } from '../data/country';
import { warehouse } from '../data/warehouse';
import { countryService } from '../services/countryService';
import { warehouseService } from '../services/warehouseService';
//declare let $: any;

@Component({
  selector: 'app-warehouse-management-page',
  templateUrl: './warehouse-management-page.component.html',
  styleUrls: ['./warehouse-management-page.component.css']
})
export class WarehouseManagementPageComponent implements OnInit {

  liCountry:country[]
  liWarehouse:warehouse[]
  warehouseObj:warehouse
  @ViewChild('f1') form1:NgForm
  name:string
  isNull:boolean
  succsMsg:string
  modalHeader:string
  errorMsg:string
  constructor(private countryService:countryService,private warehouseService:warehouseService,private router:Router) { }

  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
    this.countryService.loadAll().subscribe({
      next:data=>{
        this.liCountry=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
    this.warehouseService.loadAll().subscribe({
      next:data=>{
        this.liWarehouse=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
  }
  else{
    this.router.navigate([''])
  }
  }
  hideSuccesfullyBox(){
    $("#succesfullyRow").hide()
  }
  onSave(){
    var w = new warehouse()
    w.name = this.form1.value["txtName"]
    w.address = this.form1.value["txtAddress"]
    w.city = this.form1.value["txtCity"]
    w.country_Id = parseInt(this.form1.value["ddlCountry"])
    this.warehouseService.insert(w).subscribe({
      next:()=>{
        this.warehouseService.loadAll().subscribe({
          next:data=>{
            this.liWarehouse=data
            this.succsMsg = "created"
            $("#succesfullyRow").show()
            //$("#popupmodel").modal('toggle')
          },
          error:e=>{
            alert("error: "+e)
          }
        });
      },
      error:e=>{alert("Error: "+e),
      this.errorMsg="Please fill all required"
    }
    })
  }
  onDelete(id:number){
    if(confirm("Are you sure to delete this warehouse?")){
      this.warehouseService.delete(id).subscribe({
        next:()=>{
          this.warehouseService.loadAll().subscribe({
            next:data=>{
              this.liWarehouse=data
              this.succsMsg = "deleted"
            $("#succesfullyRow").show()
            },
            error:e=>{
              alert("error: "+e)
            }
          });
        },
        error:e=>alert("Error: "+e)
      })
  }
  }
  onSearch(text:any){
    this.name=text.target.value
    if(this.name != ""){
      this.warehouseService.search(this.name).subscribe({
        next:data=>{
          this.liWarehouse=data
        },
        error:e=>alert("Error: "+e)
      })
  }
  else{
    this.warehouseService.loadAll().subscribe({
      next:data=>{
        this.liWarehouse=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
}
  }
  addWarehouse(){
    this.errorMsg=""
    this.isNull=true
    this.modalHeader="Add"
    this.form1.form.patchValue({
      "txtName":null,
      "hidId":0,
      "txtAddress":null,
      "txtCity":null,
      "ddlCountry":0
    })
  }
  onEdit(id:number){
    this.errorMsg=""
    this.isNull=false
    this.modalHeader="Edit"
    this.warehouseService.load(id).subscribe({
      next:data=>{
        this.warehouseObj=data
        this.form1.form.patchValue({
          "txtName":this.warehouseObj.name,
          "hidId":this.warehouseObj.id,
          "txtAddress":this.warehouseObj.address,
          "txtCity":this.warehouseObj.city,
          "ddlCountry":this.warehouseObj.country_Id
        })
      },
      error:e=>alert("Error: "+e)
    })
  }
  onUpdate(){
    var w = new warehouse()
    w.id = this.form1.value["hidId"]
    w.name = this.form1.value["txtName"]
    w.address = this.form1.value["txtAddress"]
    w.city = this.form1.value["txtCity"]
    w.country_Id = parseInt(this.form1.value["ddlCountry"])
    this.countryService.update(w).subscribe({
      next:()=>{
        this.warehouseService.loadAll().subscribe({
          next:data=>{
            this.liWarehouse=data
            this.succsMsg = "updated"
            $("#succesfullyRow").show()
            //$("#popupmodel").modal('toggle')
          },
          error:e=>{
            alert("error: "+e)
          }
        });
      },
      error:e=>{alert("Error: "+e),
      this.errorMsg="Please fill all required"
    }
    })
  }
  gotoItems(id:number){
    this.router.navigate(['/item'],{queryParams:{warehouseId:id}})
  }

}
