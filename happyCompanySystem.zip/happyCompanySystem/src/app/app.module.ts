import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { WarehouseManagementPageComponent } from './warehouse-management-page/warehouse-management-page.component';
import { ItemPageComponent } from './item-page/item-page.component';
import { UserManagementPageComponent } from './user-management-page/user-management-page.component';
import { NewUserPageComponent } from './new-user-page/new-user-page.component';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { FormsModule } from '@angular/forms';
import { NewItemComponent } from './new-item/new-item.component';
import { CountryComponent } from './country/country.component';
import {HttpClientModule} from '@angular/common/http';
import { countryService } from './services/countryService';
import { warehouseService } from './services/warehouseService';
import { itemService } from './services/itemService';
import { accountService } from './services/accountService';

const appRoutes:Routes=[
  {path:'',component:LoginPageComponent},
  {path:'welcome',component:WelcomePageComponent},
  {path:'dashboard',component:DashboardPageComponent},
  {path:'warehouse',component:WarehouseManagementPageComponent},
  {path:'item',component:ItemPageComponent},
  {path:'add/item',component:NewItemComponent},
  {path:'users',component:UserManagementPageComponent},
  {path:'add/user',component:NewUserPageComponent},
  {path:'country',component:CountryComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    WelcomePageComponent,
    LoginPageComponent,
    WarehouseManagementPageComponent,
    ItemPageComponent,
    UserManagementPageComponent,
    NewUserPageComponent,
    DashboardPageComponent,
    NewItemComponent,
    CountryComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    HttpClientModule
  ],
  providers: [countryService,warehouseService,itemService,accountService],
  bootstrap: [AppComponent]
})
export class AppModule { }
