import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { item } from '../data/item';
import { itemService } from '../services/itemService';

@Component({
  selector: 'app-item-page',
  templateUrl: './item-page.component.html',
  styleUrls: ['./item-page.component.css']
})
export class ItemPageComponent implements OnInit {

  warehouseId:number=this.act.snapshot.queryParams["warehouseId"]
  liItem:item[]
  name:string
  constructor(private itemService:itemService , private act:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
    if(this.warehouseId != 0){
      this.itemService.loadByWarehouse(this.warehouseId).subscribe({
        next:data=>{
          this.liItem=data
        },
        error:e=>{
          alert("error: "+e)
        }
      });
    }
    else{
      this.itemService.loadAll().subscribe({
        next:data=>{
          this.liItem=data
        },
        error:e=>{
          alert("error: "+e)
        }
      });
    }
  }
  else{
    this.router.navigate([''])
  }
  }
  onSearch(text:any){
    this.name=text.target.value
    if(this.name != ""){
      this.itemService.search(this.name).subscribe({
        next:data=>{
          this.liItem=data
        },
        error:e=>alert("Error: "+e)
      })
  }
  else{
    this.itemService.loadAll().subscribe({
      next:data=>{
        this.liItem=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
}
  }
  onDelete(id:number){
    if(confirm("Are you sure to delete this warehouse?")){
      this.itemService.delete(id).subscribe({
        next:()=>{
          this.itemService.loadAll().subscribe({
            next:data=>{
              this.liItem=data
            },
            error:e=>{
              alert("error: "+e)
            }
          });
        },
        error:e=>alert("Error: "+e)
      })
  }
  }
  edit(id:number){
    this.router.navigate(['/add/item'],{queryParams:{itemId:id}})
  }
  addItem(){
    this.router.navigate(['/add/item'],{queryParams:{itemId:0}})
  }

}
