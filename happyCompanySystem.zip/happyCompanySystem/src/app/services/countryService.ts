import { HttpClient, HttpHeaders } from "@angular/common/http"
import { Injectable } from "@angular/core"
import { Observable, take } from "rxjs"
import { country } from "../data/country"

@Injectable()
export class countryService{
    constructor(private http:HttpClient){}

    loadAll():Observable<any>{
        
        // let Token=JSON.parse(localStorage.getItem("Token"))
        
        // const httpOptions = {
        //     headers : new HttpHeaders({
        //         'Content-Type': 'application/json',
        //         Authorization: `Bearer ${Token?.token}`
        //     })
        // }

        return this.http.get("http://localhost/HappyCompany_API/api/Country/LoadAll"/*,httpOptions*/).pipe(take(1))
    }
    insert(c:country):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Country/Insert",c).pipe(take(1))
    }
    delete(id:number):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Country/Delete?Id="+id).pipe(take(1))
    }
    search(name:string):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Country/Search?Name="+name).pipe(take(1))
    }
    load(id:number):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Country/Edit?Id="+id).pipe(take(1))
    }
    update(c:country):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Country/Update",c).pipe(take(1))
    }
}