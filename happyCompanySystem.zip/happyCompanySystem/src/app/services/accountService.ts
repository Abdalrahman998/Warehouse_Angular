import { HttpClient } from "@angular/common/http"
import { Injectable } from "@angular/core"
import { Observable, take } from "rxjs"
import { signInModel } from "../data/signInModel"
import { signUpModel } from "../data/signUpModel"

@Injectable()
export class accountService{
    constructor(private http:HttpClient){}

    getUsers():Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Account/GetUsers").pipe(take(1))
    }
    getRoles():Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Account/GetRoles").pipe(take(1))
    }
    createAccount(s:signUpModel):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Account/CreateUser",s).pipe(take(1))
    }
    login(s:signInModel):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Account/Login",s).pipe(take(1))
    }
    delete(id:string):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Account/Delete?Id="+id).pipe(take(1))
    }
    getUser(username:string):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Account/GetUser?username="+username).pipe(take(1))
    }

}