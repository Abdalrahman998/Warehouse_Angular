import { HttpClient } from "@angular/common/http"
import { Injectable } from "@angular/core"
import { Observable, take } from "rxjs"
import { warehouse } from "../data/warehouse"

@Injectable()
export class warehouseService{
    constructor(private http:HttpClient){}

    loadAll():Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Warehouse/LoadAll").pipe(take(1))
    }
    insert(w:warehouse):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Warehouse/Insert",w).pipe(take(1))
    }
    delete(id:number):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Warehouse/Delete?Id="+id).pipe(take(1))
    }
    search(name:string):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Warehouse/Search?Name="+name).pipe(take(1))
    }
    load(id:number):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Warehouse/Edit?Id="+id).pipe(take(1))
    }
    update(w:warehouse):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Warehouse/Update",w).pipe(take(1))
    }
    loadWithTotalItems():Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Warehouse/LoadTotalItems").pipe(take(1))
    }
}