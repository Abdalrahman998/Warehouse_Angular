import { HttpClient } from "@angular/common/http"
import { Injectable } from "@angular/core"
import { Observable, take } from "rxjs"
import { item } from "../data/item"

@Injectable()
export class itemService{
    constructor(private http:HttpClient){}

    loadAll():Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Item/LoadAll").pipe(take(1))
    }
    insert(i:item):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Item/Insert",i).pipe(take(1))
    }
    delete(id:number):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Item/Delete?Id="+id).pipe(take(1))
    }
    search(name:string):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Item/Search?Name="+name).pipe(take(1))
    }
    load(id:number):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Item/Edit?Id="+id).pipe(take(1))
    }
    update(i:item):Observable<any>{
        return this.http.post("http://localhost/HappyCompany_API/api/Item/Update",i).pipe(take(1))
    }
    loadByWarehouse(id:number):Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Item/LoadByWarehouse?Id="+id).pipe(take(1))
    }
    loadTop():Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Item/LoadTop").pipe(take(1))
    }
    loadLow():Observable<any>{
        return this.http.get("http://localhost/HappyCompany_API/api/Item/LoadLow").pipe(take(1))
    }
}