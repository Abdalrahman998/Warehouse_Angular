import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { item } from '../data/item';
import { itemService } from '../services/itemService';
import jwt_decode from 'jwt-decode';
import { warehouseWithTotalItems } from '../data/warehouseWithTotalItems';
import { warehouseService } from '../services/warehouseService';

@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.css']
})
export class DashboardPageComponent implements OnInit {

  decodedToken?:any=""
  role:string
  constructor(private itemService:itemService,private router:Router,private warehouseService:warehouseService) { }

  liTopItems:item[]
  liLowItems:item[]
  liWarehouseWithItems:warehouseWithTotalItems[]
  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
      var Token = (localStorage.getItem("Token"))
      this.decodedToken = jwt_decode(Token!)
      this.role = this.decodedToken.Role
      if(this.role=="Admin"){
      this.itemService.loadTop().subscribe({
      next:data=>{
        this.liTopItems=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
    this.itemService.loadLow().subscribe({
      next:data=>{
        this.liLowItems=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
    this.warehouseService.loadWithTotalItems().subscribe({
      next:data=>{
        this.liWarehouseWithItems=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
  }
  else{
    this.router.navigate([''])
  }
}
  else{
    this.router.navigate([''])
  }
}

}
