import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { role } from '../data/role';
import { signUpModel } from '../data/signUpModel';
import { accountService } from '../services/accountService';
import jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-new-user-page',
  templateUrl: './new-user-page.component.html',
  styleUrls: ['./new-user-page.component.css']
})
export class NewUserPageComponent implements OnInit {

  liRole:role[]
  @ViewChild ('f1') form1:NgForm
  succsMsg:string
  decodedToken?:any=""
  role:string
  username:string=this.act.snapshot.queryParams["username"]
  constructor(private accountService:accountService,private router:Router,private act:ActivatedRoute) { }

  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
      var Token = (localStorage.getItem("Token"))
      this.decodedToken = jwt_decode(Token!)
      this.role = this.decodedToken.Role
      if(this.role=="Admin"){
    this.accountService.getRoles().subscribe({
      next:data=>{
        this.liRole=data
      },
      error:e=>{
        alert("error: "+e)
      }
    });
  }
  else{
    this.router.navigate([''])
  }
  }
  else{
    this.router.navigate([''])
  }
  }
  hideSuccesfullyBox(){
    $("#succesfullyRow").hide()
  }
  onSave(){
    var s = new signUpModel()
    s.firstName = this.form1.value["txtFname"]
    s.middleName = this.form1.value["txtMname"]
    s.lastName = this.form1.value["txtLname"]
    s.email = this.form1.value["txtEmail"]
    s.roleId = this.form1.value["ddlRole"]
    s.password = this.form1.value["txtPassword"]
    s.confirmPassword = this.form1.value["txtConfirmPassworad"]
    this.accountService.createAccount(s).subscribe({
      next:()=>{
        this.succsMsg="created"
          $("#succesfullyRow").show()
          },
      error:e=>alert("Error: "+e)
    })
  }

}
