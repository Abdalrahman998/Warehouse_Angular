import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import jwtDecode from 'jwt-decode';
import { signInModel } from '../data/signInModel';
import { accountService } from '../services/accountService';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  invalidMsg:string
  @ViewChild ('f1') form1:NgForm
  constructor(private accountService:accountService,private router:Router) { }

  ngOnInit(): void {
    let token=localStorage.getItem("Token")
    if(token){
      localStorage.clear();
    }
    if (!localStorage.getItem('foo')) { 
      localStorage.setItem('foo', 'no reload') 
      location.reload() 
    } else {
      localStorage.removeItem('foo') 
    }
  }
  login(){
    var s = new signInModel()
    s.username = this.form1.value["txtName"]
    s.password = this.form1.value["txtPassword"]
    this.accountService.login(s).subscribe({
      next:(data)=>{
          console.log(data)
          this.invalidMsg=""
          debugger
          localStorage.setItem("Token",data.token)
          this.router.navigate(['/welcome'],{queryParams:{username:this.form1.value["txtName"]}})
          },
      error:()=>{
        this.invalidMsg="Invalid Username or Password"
      }
    })
  }

}
